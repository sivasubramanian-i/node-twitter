import React from "react";
import "./App.css";
import myData from "./data/data.json";

class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      result: ""
    };
  }

  convert(array) {
    var map = {};
    for (var i = 0; i < array.length; i++) {
      var obj = array[i];
      obj.children = [];

      map[obj.beneficiaryPayId] = obj;

      var parent = obj.parentBenePayId || "-";
      if (!map[parent]) {
        map[parent] = {
          children: []
        };
      }
      map[parent].children.push(obj);
    }

    return map["-"].children;
  }
  componentWillMount() {
    this.state.result = this.convert(myData.input.payBeneficiaries);
  }
  handleClick() {
    let result = this.convert(myData.input.payBeneficiaries);
    this.setState(state => ({ result: result }));
  }

  render() {
    return (
      <div>
        <pre>{JSON.stringify(this.state.result[0])}</pre>
      </div>
    );
  }
}
export default App;
